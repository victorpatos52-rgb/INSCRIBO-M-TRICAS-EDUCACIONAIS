-- =====================================================
-- INSCRIBO MÉTRICAS EDUCACIONAIS
-- Estrutura de Banco de Dados Supabase
-- =====================================================

-- Tabela de Escolas
CREATE TABLE IF NOT EXISTS escolas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  codigo_inep TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  cidade TEXT NOT NULL,
  estado TEXT NOT NULL,
  dependencia TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_escolas_codigo_inep ON escolas(codigo_inep);
CREATE INDEX idx_escolas_cidade ON escolas(cidade);
CREATE INDEX idx_escolas_estado ON escolas(estado);
CREATE INDEX idx_escolas_nome ON escolas USING gin(to_tsvector('portuguese', nome));

-- Tabela de Matrículas
CREATE TABLE IF NOT EXISTS matriculas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  escola_id UUID REFERENCES escolas(id) ON DELETE CASCADE,
  ano INTEGER NOT NULL,
  infantil INTEGER DEFAULT 0,
  fundamental1 INTEGER DEFAULT 0,
  fundamental2 INTEGER DEFAULT 0,
  medio INTEGER DEFAULT 0,
  total INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(escola_id, ano)
);

CREATE INDEX idx_matriculas_escola_id ON matriculas(escola_id);
CREATE INDEX idx_matriculas_ano ON matriculas(ano);

-- Tabela ENEM
CREATE TABLE IF NOT EXISTS enem (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  escola_id UUID REFERENCES escolas(id) ON DELETE CASCADE,
  ano INTEGER NOT NULL,
  media_total DECIMAL(5,2) DEFAULT 0,
  redacao DECIMAL(5,2) DEFAULT 0,
  matematica DECIMAL(5,2) DEFAULT 0,
  linguagens DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(escola_id, ano)
);

CREATE INDEX idx_enem_escola_id ON enem(escola_id);
CREATE INDEX idx_enem_ano ON enem(ano);

-- Tabela de Relatórios
CREATE TABLE IF NOT EXISTS relatorios (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  escola_id UUID REFERENCES escolas(id) ON DELETE CASCADE,
  token TEXT UNIQUE NOT NULL,
  data_geracao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  resumo_executivo TEXT,
  projecoes_json TEXT,
  senha TEXT,
  expira_em TIMESTAMP WITH TIME ZONE,
  visualizacoes INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_relatorios_token ON relatorios(token);
CREATE INDEX idx_relatorios_escola_id ON relatorios(escola_id);

-- Tabela de Configurações
CREATE TABLE IF NOT EXISTS configuracoes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  taxa_conversao_padrao DECIMAL(5,4) DEFAULT 0.15,
  taxa_evasao_padrao DECIMAL(5,4) DEFAULT 0.05,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir configuração padrão
INSERT INTO configuracoes (taxa_conversao_padrao, taxa_evasao_padrao) 
VALUES (0.15, 0.05)
ON CONFLICT DO NOTHING;

-- =====================================================
-- DADOS DE EXEMPLO (PARA TESTES)
-- =====================================================

-- Exemplo: Escolas de São Paulo
INSERT INTO escolas (codigo_inep, nome, cidade, estado, dependencia) VALUES
  ('35001234', 'Colégio Exemplo Paulista', 'São Paulo', 'SP', 'Privada'),
  ('35005678', 'Escola Teste ABC', 'São Paulo', 'SP', 'Privada'),
  ('33001122', 'Instituto Educacional Rio', 'Rio de Janeiro', 'RJ', 'Privada')
ON CONFLICT (codigo_inep) DO NOTHING;

-- Exemplo: Matrículas dos últimos 3 anos
INSERT INTO matriculas (escola_id, ano, infantil, fundamental1, fundamental2, medio, total)
SELECT 
  e.id,
  2023,
  120,
  250,
  180,
  150,
  700
FROM escolas e
WHERE e.codigo_inep = '35001234'
ON CONFLICT (escola_id, ano) DO NOTHING;

INSERT INTO matriculas (escola_id, ano, infantil, fundamental1, fundamental2, medio, total)
SELECT 
  e.id,
  2024,
  135,
  270,
  195,
  160,
  760
FROM escolas e
WHERE e.codigo_inep = '35001234'
ON CONFLICT (escola_id, ano) DO NOTHING;

INSERT INTO matriculas (escola_id, ano, infantil, fundamental1, fundamental2, medio, total)
SELECT 
  e.id,
  2025,
  150,
  290,
  210,
  170,
  820
FROM escolas e
WHERE e.codigo_inep = '35001234'
ON CONFLICT (escola_id, ano) DO NOTHING;

-- Exemplo: Dados ENEM
INSERT INTO enem (escola_id, ano, media_total, redacao, matematica, linguagens)
SELECT 
  e.id,
  2023,
  650.5,
  720.0,
  620.0,
  640.0
FROM escolas e
WHERE e.codigo_inep = '35001234'
ON CONFLICT (escola_id, ano) DO NOTHING;

INSERT INTO enem (escola_id, ano, media_total, redacao, matematica, linguagens)
SELECT 
  e.id,
  2024,
  665.2,
  735.0,
  640.0,
  655.0
FROM escolas e
WHERE e.codigo_inep = '35001234'
ON CONFLICT (escola_id, ano) DO NOTHING;

-- =====================================================
-- POLÍTICAS RLS (Row Level Security)
-- =====================================================

-- Habilitar RLS
ALTER TABLE escolas ENABLE ROW LEVEL SECURITY;
ALTER TABLE matriculas ENABLE ROW LEVEL SECURITY;
ALTER TABLE enem ENABLE ROW LEVEL SECURITY;
ALTER TABLE relatorios ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes ENABLE ROW LEVEL SECURITY;

-- Política: Permitir leitura pública para todas as tabelas
CREATE POLICY "Allow public read access" ON escolas FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON matriculas FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON enem FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON relatorios FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON configuracoes FOR SELECT USING (true);

-- Política: Permitir inserção via service role
CREATE POLICY "Allow service role insert" ON escolas FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow service role insert" ON matriculas FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow service role insert" ON enem FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow service role insert" ON relatorios FOR INSERT WITH CHECK (true);

-- =====================================================
-- FUNÇÕES UTILITÁRIAS
-- =====================================================

-- Função para atualizar campo updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para configuracoes
CREATE TRIGGER update_configuracoes_updated_at
BEFORE UPDATE ON configuracoes
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- FIM DO SCRIPT
-- =====================================================
