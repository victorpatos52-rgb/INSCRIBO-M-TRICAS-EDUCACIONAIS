import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import { GoogleGenerativeAI } from "npm:@google/generative-ai";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize Supabase
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Initialize Gemini
const genAI = new GoogleGenerativeAI(Deno.env.get('GEMINI_API_KEY') ?? '');

// Health check endpoint
app.get("/make-server-ec6f1a33/health", (c) => {
  return c.json({ status: "ok" });
});

// Search schools endpoint
app.post("/make-server-ec6f1a33/search-schools", async (c) => {
  try {
    const body = await c.req.json();
    const { query, cidade, estado } = body;

    let queryBuilder = supabase
      .from('escolas')
      .select('*');

    if (query) {
      queryBuilder = queryBuilder.or(`nome.ilike.%${query}%,codigo_inep.eq.${query}`);
    }
    if (cidade) {
      queryBuilder = queryBuilder.ilike('cidade', `%${cidade}%`);
    }
    if (estado) {
      queryBuilder = queryBuilder.eq('estado', estado);
    }

    const { data, error } = await queryBuilder.limit(50);

    if (error) {
      console.log(`Error searching schools: ${error.message}`);
      return c.json({ error: error.message }, 500);
    }

    return c.json({ escolas: data || [] });
  } catch (error) {
    console.log(`Error in search-schools endpoint: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Generate report endpoint
app.post("/make-server-ec6f1a33/generate-report", async (c) => {
  try {
    const body = await c.req.json();
    const { escola_id } = body;

    // Fetch school data
    const { data: escola, error: escolaError } = await supabase
      .from('escolas')
      .select('*')
      .eq('id', escola_id)
      .single();

    if (escolaError || !escola) {
      console.log(`Error fetching school: ${escolaError?.message}`);
      return c.json({ error: 'Escola não encontrada' }, 404);
    }

    // Fetch matriculas (last 3 years)
    const currentYear = 2025;
    const { data: matriculas, error: matriculasError } = await supabase
      .from('matriculas')
      .select('*')
      .eq('escola_id', escola_id)
      .gte('ano', currentYear - 2)
      .order('ano', { ascending: true });

    if (matriculasError) {
      console.log(`Error fetching matriculas: ${matriculasError.message}`);
    }

    // Fetch ENEM data
    const { data: enem, error: enemError } = await supabase
      .from('enem')
      .select('*')
      .eq('escola_id', escola_id)
      .order('ano', { ascending: false })
      .limit(3);

    if (enemError) {
      console.log(`Error fetching ENEM data: ${enemError.message}`);
    }

    // Fetch IBGE data
    const ibgeData = await fetchIBGEData(escola.cidade, escola.estado);

    // Calculate metrics
    const metrics = calculateMetrics(matriculas || [], ibgeData);

    // Fetch configuration
    const { data: config } = await supabase
      .from('configuracoes')
      .select('*')
      .single();

    const taxaConversao = config?.taxa_conversao_padrao || 0.15;
    const taxaEvasao = config?.taxa_evasao_padrao || 0.05;

    // Generate strategic analysis with Gemini
    const analiseIA = await generateGeminiAnalysis({
      escola,
      matriculas: matriculas || [],
      enem: enem || [],
      ibgeData,
      metrics,
      taxaConversao,
      taxaEvasao,
    });

    // Generate unique token
    const token = generateToken();

    // Save report
    const { data: relatorio, error: relatorioError } = await supabase
      .from('relatorios')
      .insert({
        escola_id,
        token,
        data_geracao: new Date().toISOString(),
        resumo_executivo: analiseIA.resumo,
        projecoes_json: JSON.stringify({
          metrics,
          analiseIA,
          ibgeData,
          enem: enem || [],
        }),
      })
      .select()
      .single();

    if (relatorioError) {
      console.log(`Error saving report: ${relatorioError.message}`);
      return c.json({ error: 'Erro ao salvar relatório' }, 500);
    }

    return c.json({ 
      success: true, 
      token,
      relatorio_id: relatorio.id 
    });
  } catch (error) {
    console.log(`Error in generate-report endpoint: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Get report by token
app.get("/make-server-ec6f1a33/report/:token", async (c) => {
  try {
    const token = c.req.param('token');

    const { data: relatorio, error } = await supabase
      .from('relatorios')
      .select(`
        *,
        escolas (*)
      `)
      .eq('token', token)
      .single();

    if (error || !relatorio) {
      console.log(`Error fetching report: ${error?.message}`);
      return c.json({ error: 'Relatório não encontrado' }, 404);
    }

    // Fetch matriculas
    const { data: matriculas } = await supabase
      .from('matriculas')
      .select('*')
      .eq('escola_id', relatorio.escola_id)
      .order('ano', { ascending: true });

    return c.json({
      relatorio,
      matriculas: matriculas || [],
      projecoes: JSON.parse(relatorio.projecoes_json || '{}'),
    });
  } catch (error) {
    console.log(`Error in report endpoint: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Helper: Fetch IBGE data
async function fetchIBGEData(cidade: string, estado: string) {
  try {
    // Simulated IBGE data - In production, use real IBGE API
    return {
      populacao_0_4: 15000,
      populacao_5_9: 18000,
      populacao_10_14: 20000,
      populacao_15_17: 12000,
      crescimento_anual: 0.012,
      renda_media: 2500,
    };
  } catch (error) {
    console.log(`Error fetching IBGE data: ${error}`);
    return {
      populacao_0_4: 0,
      populacao_5_9: 0,
      populacao_10_14: 0,
      populacao_15_17: 0,
      crescimento_anual: 0,
      renda_media: 0,
    };
  }
}

// Helper: Calculate metrics
function calculateMetrics(matriculas: any[], ibgeData: any) {
  if (!matriculas || matriculas.length === 0) {
    return {
      crescimento_anual: [],
      taxa_media: 0,
      segmento_dominante: 'N/A',
      segmento_em_queda: 'N/A',
      market_share: 0,
      potencial_maximo: 0,
      taxa_reposicao: 0,
    };
  }

  // Calculate annual growth
  const crescimentoAnual = [];
  for (let i = 1; i < matriculas.length; i++) {
    const prev = matriculas[i - 1];
    const curr = matriculas[i];
    const growth = ((curr.total - prev.total) / prev.total) * 100;
    crescimentoAnual.push({
      ano: curr.ano,
      crescimento: growth,
    });
  }

  // Calculate average growth rate
  const taxaMedia = crescimentoAnual.length > 0
    ? crescimentoAnual.reduce((sum, item) => sum + item.crescimento, 0) / crescimentoAnual.length
    : 0;

  // Identify dominant and declining segments
  const ultimaMatricula = matriculas[matriculas.length - 1];
  const segmentos = {
    'Infantil': ultimaMatricula.infantil || 0,
    'Fundamental I': ultimaMatricula.fundamental1 || 0,
    'Fundamental II': ultimaMatricula.fundamental2 || 0,
    'Médio': ultimaMatricula.medio || 0,
  };

  const segmentoDominante = Object.entries(segmentos).reduce((a, b) => 
    a[1] > b[1] ? a : b
  )[0];

  // Simulate market share (assume 20% of city population is in private schools)
  const populacaoTotal = ibgeData.populacao_0_4 + ibgeData.populacao_5_9 + 
                          ibgeData.populacao_10_14 + ibgeData.populacao_15_17;
  const marketShare = (ultimaMatricula.total / (populacaoTotal * 0.2)) * 100;

  return {
    crescimento_anual: crescimentoAnual,
    taxa_media: taxaMedia,
    segmento_dominante: segmentoDominante,
    segmento_em_queda: 'Médio', // Simplified
    market_share: marketShare,
    potencial_maximo: populacaoTotal * 0.2,
    taxa_reposicao: ultimaMatricula.total * 0.05,
  };
}

// Helper: Generate Gemini analysis
async function generateGeminiAnalysis(data: any) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const prompt = `
Você é um consultor estratégico educacional especializado em análise de mercado escolar.

Analise os seguintes dados da escola "${data.escola.nome}" (${data.escola.cidade}/${data.escola.estado}):

DADOS HISTÓRICOS DE MATRÍCULA:
${JSON.stringify(data.matriculas, null, 2)}

MÉTRICAS CALCULADAS:
- Taxa de crescimento média: ${data.metrics.taxa_media.toFixed(2)}%
- Segmento dominante: ${data.metrics.segmento_dominante}
- Market share estimado: ${data.metrics.market_share.toFixed(2)}%
- Potencial máximo estimado: ${data.metrics.potencial_maximo.toFixed(0)} alunos

DADOS DEMOGRÁFICOS (IBGE):
${JSON.stringify(data.ibgeData, null, 2)}

DADOS ENEM (últimos anos):
${JSON.stringify(data.enem, null, 2)}

TAXAS OPERACIONAIS:
- Taxa de conversão: ${(data.taxaConversao * 100).toFixed(0)}%
- Taxa de evasão: ${(data.taxaEvasao * 100).toFixed(0)}%

Forneça uma análise estratégica completa em formato JSON com as seguintes seções:

{
  "resumo": "Resumo executivo de 2-3 parágrafos sobre a situação atual da escola",
  "diagnostico": "Diagnóstico detalhado dos pontos fortes e fracos",
  "riscos": ["Lista de 3-5 riscos identificados"],
  "oportunidades": ["Lista de 3-5 oportunidades"],
  "meta_recomendada": "Meta de crescimento recomendada com justificativa",
  "estrategia_crescimento": "Estratégia detalhada de crescimento",
  "plano_captacao": ["Lista de 5-7 ações específicas para captação"],
  "plano_geografico": "Recomendações de expansão geográfica ou consolidação",
  "recomendacoes_executivas": ["Lista de 5 recomendações prioritárias para a direção"]
}

Seja específico, consultivo e estratégico. Use dados concretos da análise.
`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    // Try to parse JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }

    // Fallback if JSON parsing fails
    return {
      resumo: text.substring(0, 500),
      diagnostico: "Análise completa disponível no relatório",
      riscos: ["Análise em processamento"],
      oportunidades: ["Análise em processamento"],
      meta_recomendada: "Crescimento moderado de 10-15% ao ano",
      estrategia_crescimento: text,
      plano_captacao: ["Intensificar marketing digital", "Programa de indicação"],
      plano_geografico: "Consolidar presença no município atual",
      recomendacoes_executivas: ["Revisar estratégia de captação"],
    };
  } catch (error) {
    console.log(`Error generating Gemini analysis: ${error}`);
    return {
      resumo: "Análise automática indisponível. Contate o suporte.",
      diagnostico: "Erro ao processar análise",
      riscos: [],
      oportunidades: [],
      meta_recomendada: "N/A",
      estrategia_crescimento: "N/A",
      plano_captacao: [],
      plano_geografico: "N/A",
      recomendacoes_executivas: [],
    };
  }
}

// Helper: Generate unique token
function generateToken(): string {
  return Array.from({ length: 32 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
}

Deno.serve(app.fetch);
