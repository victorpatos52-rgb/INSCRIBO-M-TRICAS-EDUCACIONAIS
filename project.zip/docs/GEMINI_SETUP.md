# Configuração do Google Gemini API

Este guia explica como configurar e usar a API do Google Gemini no sistema Inscribo Métricas.

## Por Que Gemini?

O Google Gemini foi escolhido para substituir o OpenAI porque:

✅ **Custo-benefício superior** - Preços mais acessíveis para uso em produção  
✅ **Modelo Gemini Pro gratuito** - Até 60 requisições por minuto sem custo  
✅ **Melhor suporte multilíngue** - Português nativo sem traduções  
✅ **Contexto grande** - Até 1 milhão de tokens (vs 128k do GPT-4)  
✅ **Integração Google** - Compatível com outros serviços Google  

## Passo 1: Criar Conta Google Cloud

1. Acesse [Google AI Studio](https://makersuite.google.com/)
2. Faça login com sua conta Google
3. Aceite os termos de serviço

## Passo 2: Obter API Key

1. No Google AI Studio, clique em **"Get API Key"**
2. Selecione um projeto existente ou crie um novo
3. Clique em **"Create API Key"**
4. Copie a chave gerada (começará com `AIza...`)

⚠️ **IMPORTANTE:** Guarde esta chave em local seguro. Não compartilhe publicamente.

## Passo 3: Configurar no Supabase

### Via Dashboard (Recomendado)

1. Acesse seu projeto no [Supabase Dashboard](https://app.supabase.com)
2. Vá em **Settings → Edge Functions**
3. Clique em **"Manage secrets"**
4. Adicione um novo secret:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** Cole sua chave API do Gemini
5. Clique em **Save**

### Via CLI (Alternativo)

```bash
# Instalar Supabase CLI
npm install -g supabase

# Login
supabase login

# Link ao projeto
supabase link --project-ref seu-project-id

# Adicionar secret
supabase secrets set GEMINI_API_KEY=sua-chave-aqui
```

## Passo 4: Verificar Configuração

Teste se a API está funcionando corretamente:

```bash
# No terminal, execute:
curl https://seu-projeto.supabase.co/functions/v1/make-server-ec6f1a33/health \
  -H "Authorization: Bearer SUA-ANON-KEY"
```

Se retornar `{"status":"ok"}`, está funcionando.

## Modelos Disponíveis

O sistema usa o modelo **gemini-pro**, mas você pode alterar conforme necessidade:

| Modelo | Descrição | Melhor para |
|--------|-----------|-------------|
| `gemini-pro` | Modelo texto padrão | Análises textuais, relatórios |
| `gemini-pro-vision` | Modelo com visão | Análise de imagens, gráficos |
| `gemini-1.5-pro` | Versão mais recente | Contextos grandes, análises complexas |
| `gemini-1.5-flash` | Versão rápida | Respostas rápidas, menor custo |

### Como Alterar o Modelo

Edite `/supabase/functions/server/index.tsx`:

```typescript
// Linha ~145
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
```

## Limites e Custos

### Tier Gratuito (Free)
- **60 requisições por minuto**
- **1.500 requisições por dia**
- **1 milhão de tokens por minuto**
- Ideal para desenvolvimento e MVPs

### Tier Pago (Pay-as-you-go)
- **Gemini Pro:** $0.00025 / 1K caracteres (entrada)
- **Gemini Pro:** $0.0005 / 1K caracteres (saída)
- **Gemini 1.5 Pro:** $0.00125 / 1K caracteres (entrada)
- **Gemini 1.5 Flash:** $0.000125 / 1K caracteres (entrada)

**Exemplo de custo real:**
- Relatório típico: ~5.000 caracteres de entrada + 3.000 de saída
- Custo por relatório: ~$0.002 (0,2 centavos de dólar)
- 1.000 relatórios: ~$2.00

### Habilitar Billing

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Vá em **Billing → Link a billing account**
3. Adicione método de pagamento
4. Defina alertas de budget (recomendado: $10-50/mês)

## Prompt Engineering

O sistema usa um prompt estruturado. Você pode otimizar em `/supabase/functions/server/index.tsx` (função `generateGeminiAnalysis`):

### Dicas de Otimização

```typescript
const prompt = `
Você é um consultor estratégico educacional especializado em análise de mercado escolar.

[CONTEXTO]
Escola: ${data.escola.nome}
Localização: ${data.escola.cidade}/${data.escola.estado}
Dependência: ${data.escola.dependencia}

[DADOS HISTÓRICOS]
${formatarMatriculas(data.matriculas)}

[MÉTRICAS CALCULADAS]
Taxa de crescimento média: ${data.metrics.taxa_media.toFixed(2)}%
Market share estimado: ${data.metrics.market_share.toFixed(2)}%
Segmento dominante: ${data.metrics.segmento_dominante}

[TAREFA]
Forneça uma análise estratégica em formato JSON com as seguintes seções:
{
  "resumo": "2-3 parágrafos executivos",
  "diagnostico": "Análise detalhada SWOT",
  "riscos": ["3-5 riscos específicos com dados"],
  "oportunidades": ["3-5 oportunidades concretas"],
  "meta_recomendada": "Meta % com justificativa baseada em dados",
  "estrategia_crescimento": "Plano detalhado de 12-24 meses",
  "plano_captacao": ["5-7 ações específicas e mensuráveis"],
  "plano_geografico": "Recomendação de expansão/consolidação",
  "recomendacoes_executivas": ["5 ações prioritárias para diretoria"]
}

[FORMATO]
- Seja específico e use números dos dados fornecidos
- Evite generalizações
- Priorize ações práticas e executáveis
- Tom: consultivo, estratégico, data-driven
`;
```

### Melhorando a Qualidade

1. **Seja específico nos dados:** Mais contexto = melhores análises
2. **Use exemplos:** Adicione exemplos de análises desejadas no prompt
3. **Formato estruturado:** JSON garante parseabilidade
4. **Temperatura baixa:** Use `temperature: 0.3` para análises consistentes
5. **Top-k e Top-p:** Configure para respostas mais focadas

## Segurança

### Boas Práticas

✅ **NUNCA** exponha a API key no frontend  
✅ **SEMPRE** use via Edge Functions (backend)  
✅ **Rotacione** chaves periodicamente (a cada 3-6 meses)  
✅ **Configure** rate limiting para prevenir abuso  
✅ **Monitore** uso via Google Cloud Console  

### Rate Limiting

Implemente rate limiting no backend:

```typescript
// Exemplo simples de rate limiting
const rateLimitMap = new Map();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const userRequests = rateLimitMap.get(ip) || [];
  
  // Filtrar requisições dos últimos 60 segundos
  const recentRequests = userRequests.filter(time => now - time < 60000);
  
  if (recentRequests.length >= 10) { // Max 10 por minuto
    return false;
  }
  
  recentRequests.push(now);
  rateLimitMap.set(ip, recentRequests);
  return true;
}
```

## Monitoramento

### Dashboard Google Cloud

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Vá em **APIs & Services → Dashboard**
3. Selecione **Generative Language API**
4. Visualize:
   - Requisições por dia
   - Latência média
   - Erros
   - Custos

### Logs no Supabase

Visualize logs das Edge Functions:

```bash
# Via CLI
supabase functions logs make-server-ec6f1a33

# Ou no Dashboard
Supabase → Edge Functions → make-server-ec6f1a33 → Logs
```

## Troubleshooting

### Erro: "API key not valid"

**Solução:**
1. Verifique se copiou a chave completa (começa com `AIza...`)
2. Confirme que adicionou como secret no Supabase
3. Aguarde 1-2 minutos após adicionar (propagação)
4. Redeploy da Edge Function

```bash
supabase functions deploy make-server-ec6f1a33
```

### Erro: "Quota exceeded"

**Solução:**
1. Verifique seu tier no Google Cloud Console
2. Se free tier: aguarde reset diário ou habilite billing
3. Se paid: aumente quota ou otimize uso

### Erro: "Safety block"

O Gemini bloqueou a resposta por conteúdo impróprio.

**Solução:**
```typescript
const model = genAI.getGenerativeModel({ 
  model: "gemini-pro",
  safetySettings: [
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    },
  ],
});
```

### Resposta malformada (JSON inválido)

**Solução:**
```typescript
// Adicionar retry logic
let analise;
try {
  const text = response.text();
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  analise = jsonMatch ? JSON.parse(jsonMatch[0]) : defaultAnalise;
} catch (error) {
  console.log('Erro ao parsear JSON, usando fallback');
  analise = defaultAnalise;
}
```

## Testes

### Teste Manual

```bash
# Gerar relatório de teste
curl -X POST https://seu-projeto.supabase.co/functions/v1/make-server-ec6f1a33/generate-report \
  -H "Authorization: Bearer SUA-ANON-KEY" \
  -H "Content-Type: application/json" \
  -d '{"escola_id":"uuid-da-escola"}'
```

### Teste de Análise IA

```typescript
// Criar função de teste
async function testarGemini() {
  const model = genAI.getGenerativeModel({ model: "gemini-pro" });
  const prompt = "Escreva uma análise breve sobre crescimento escolar.";
  
  const result = await model.generateContent(prompt);
  console.log(result.response.text());
}
```

## Alternativas ao Gemini

Se preferir outras APIs de IA:

### OpenAI (GPT-4)
```typescript
import OpenAI from "npm:openai";

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const completion = await openai.chat.completions.create({
  model: "gpt-4",
  messages: [{ role: "user", content: prompt }],
});
```

### Anthropic (Claude)
```typescript
import Anthropic from "npm:@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: Deno.env.get('ANTHROPIC_API_KEY') });
const message = await anthropic.messages.create({
  model: "claude-3-opus-20240229",
  messages: [{ role: "user", content: prompt }],
});
```

### Cohere
```typescript
import { CohereClient } from "npm:cohere-ai";

const cohere = new CohereClient({ token: Deno.env.get('COHERE_API_KEY') });
const response = await cohere.generate({ prompt, model: "command" });
```

## Recursos Adicionais

- [Google AI Studio](https://makersuite.google.com/)
- [Documentação Gemini API](https://ai.google.dev/docs)
- [Pricing Calculator](https://ai.google.dev/pricing)
- [Community Forum](https://discuss.ai.google.dev/)
- [GitHub Samples](https://github.com/google/generative-ai-docs)

## Suporte

Problemas com Gemini API:
- **Documentação:** https://ai.google.dev/docs
- **Status:** https://status.cloud.google.com/
- **Suporte:** https://cloud.google.com/support

Problemas com integração Inscribo:
- Consultar README.md principal
- Verificar logs do Supabase Edge Functions
