# Guia de Importação de Dados do INEP

Este guia explica como importar dados oficiais do Censo Escolar (INEP) para o sistema.

## Fontes de Dados Oficiais

### 1. Censo Escolar (INEP)
**URL:** https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/censo-escolar

**Dados disponíveis:**
- Cadastro de escolas
- Matrículas por etapa de ensino
- Infraestrutura escolar
- Docentes

**Formato:** CSV (microdados)

### 2. ENEM (INEP)
**URL:** https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/enem

**Dados disponíveis:**
- Médias por escola
- Desempenho por área de conhecimento
- Resultados individualizados (anonimizados)

**Formato:** CSV

### 3. IBGE
**API Online:** https://servicodados.ibge.gov.br/api/docs

**Endpoints úteis:**
- `/api/v1/projecoes/populacao/{municipio}` - Projeções populacionais
- `/api/v3/agregados/{indicador}/periodos/{periodo}/localidades/{localidade}` - Indicadores diversos

## Processo de Importação

### Passo 1: Download dos Microdados

```bash
# Exemplo: Baixar Censo Escolar 2024
wget https://download.inep.gov.br/microdados/microdados_censo_escolar_2024.zip
unzip microdados_censo_escolar_2024.zip
```

### Passo 2: Processar Arquivos CSV

Os microdados vêm em formato CSV grande. Você precisará de um script Python ou Node.js para processar:

**Estrutura típica do CSV de escolas:**
```csv
CO_ENTIDADE,NO_ENTIDADE,CO_MUNICIPIO,SG_UF,TP_DEPENDENCIA,...
35001234,Colégio Exemplo,3550308,SP,4,...
```

**Campos importantes:**
- `CO_ENTIDADE` → codigo_inep
- `NO_ENTIDADE` → nome
- `CO_MUNICIPIO` → buscar nome no IBGE
- `SG_UF` → estado
- `TP_DEPENDENCIA` → 1=Federal, 2=Estadual, 3=Municipal, 4=Privada

### Passo 3: Script de Importação (Exemplo em Python)

```python
import pandas as pd
from supabase import create_client, Client

# Configurar Supabase
url = "https://seu-projeto.supabase.co"
key = "sua-service-role-key"
supabase: Client = create_client(url, key)

# Ler CSV
df = pd.read_csv('escolas.csv', encoding='latin1', sep='|')

# Filtrar apenas escolas privadas
df_privadas = df[df['TP_DEPENDENCIA'] == 4]

# Processar e inserir
for index, row in df_privadas.iterrows():
    dados = {
        'codigo_inep': str(row['CO_ENTIDADE']),
        'nome': row['NO_ENTIDADE'],
        'cidade': get_cidade_nome(row['CO_MUNICIPIO']),  # Função auxiliar
        'estado': row['SG_UF'],
        'dependencia': 'Privada'
    }
    
    try:
        supabase.table('escolas').insert(dados).execute()
        print(f"✓ Inserida: {dados['nome']}")
    except Exception as e:
        print(f"✗ Erro: {e}")

print("Importação concluída!")
```

### Passo 4: Importar Matrículas

**CSV de matrículas típico:**
```csv
CO_ENTIDADE,NU_ANO_CENSO,QT_MAT_INF,QT_MAT_FUND_AI,QT_MAT_FUND_AF,QT_MAT_MED
35001234,2024,150,290,210,170
```

**Script:**
```python
df_matriculas = pd.read_csv('matriculas.csv', encoding='latin1', sep='|')

for index, row in df_matriculas.iterrows():
    # Buscar escola_id pelo codigo_inep
    escola = supabase.table('escolas').select('id').eq('codigo_inep', str(row['CO_ENTIDADE'])).execute()
    
    if escola.data:
        dados = {
            'escola_id': escola.data[0]['id'],
            'ano': int(row['NU_ANO_CENSO']),
            'infantil': int(row['QT_MAT_INF']),
            'fundamental1': int(row['QT_MAT_FUND_AI']),
            'fundamental2': int(row['QT_MAT_FUND_AF']),
            'medio': int(row['QT_MAT_MED']),
            'total': int(row['QT_MAT_INF'] + row['QT_MAT_FUND_AI'] + row['QT_MAT_FUND_AF'] + row['QT_MAT_MED'])
        }
        
        supabase.table('matriculas').upsert(dados).execute()
```

### Passo 5: Importar ENEM

```python
df_enem = pd.read_csv('enem_escola.csv', encoding='latin1', sep='|')

for index, row in df_enem.iterrows():
    escola = supabase.table('escolas').select('id').eq('codigo_inep', str(row['CO_ESCOLA_EDUCACENSO'])).execute()
    
    if escola.data:
        dados = {
            'escola_id': escola.data[0]['id'],
            'ano': int(row['NU_ANO']),
            'media_total': float(row['MEDIA_GERAL']),
            'redacao': float(row['MEDIA_REDACAO']),
            'matematica': float(row['MEDIA_MATEMATICA']),
            'linguagens': float(row['MEDIA_LINGUAGENS'])
        }
        
        supabase.table('enem').upsert(dados).execute()
```

## Integração com API do IBGE

### Exemplo: Buscar População por Município

```javascript
async function fetchPopulacaoIBGE(codigoMunicipio) {
  // Projeção populacional
  const urlPopulacao = `https://servicodados.ibge.gov.br/api/v1/projecoes/populacao/${codigoMunicipio}`;
  
  const response = await fetch(urlPopulacao);
  const data = await response.json();
  
  // Processar por faixa etária
  const faixas = {
    '0-4': data.projecao.filter(p => p.idade >= 0 && p.idade <= 4).reduce((sum, p) => sum + p.populacao, 0),
    '5-9': data.projecao.filter(p => p.idade >= 5 && p.idade <= 9).reduce((sum, p) => sum + p.populacao, 0),
    '10-14': data.projecao.filter(p => p.idade >= 10 && p.idade <= 14).reduce((sum, p) => sum + p.populacao, 0),
    '15-17': data.projecao.filter(p => p.idade >= 15 && p.idade <= 17).reduce((sum, p) => sum + p.populacao, 0),
  };
  
  return faixas;
}

// Exemplo: Buscar renda média
async function fetchRendaMedia(codigoMunicipio) {
  const url = `https://servicodados.ibge.gov.br/api/v3/agregados/6579/periodos/2021/localidades/${codigoMunicipio}`;
  const response = await fetch(url);
  const data = await response.json();
  return data[0].resultados[0].series[0].serie['2021'];
}
```

## Automatização

Para manter os dados atualizados, crie um cron job ou scheduled function:

```javascript
// Supabase Edge Function agendada (via Supabase Cron)
Deno.cron("Atualizar dados INEP", "0 0 1 * *", async () => {
  // Executar importação mensal
  console.log("Iniciando atualização mensal de dados...");
  // Seu código de importação aqui
});
```

## Conformidade LGPD

⚠️ **IMPORTANTE:** Os dados do INEP são públicos, mas:

1. Não armazene dados pessoais identificáveis de alunos
2. Use apenas dados agregados (totais por escola)
3. Para ENEM, use apenas médias por escola (sem dados individuais)
4. Implemente política de privacidade clara
5. Permita que escolas solicitem remoção de seus dados

## Checklist de Importação

- [ ] Download dos microdados oficiais mais recentes
- [ ] Filtrar apenas escolas privadas (ou conforme escopo)
- [ ] Validar formato dos dados (código INEP, anos, etc.)
- [ ] Importar escolas
- [ ] Importar matrículas (últimos 3-5 anos)
- [ ] Importar dados ENEM disponíveis
- [ ] Validar integridade referencial (escola_id)
- [ ] Testar geração de relatórios com dados reais
- [ ] Documentar fontes e data de atualização

## Recursos Adicionais

- [Portal de Dados Abertos INEP](https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos)
- [Dicionário de Variáveis do Censo Escolar](https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/censo-escolar)
- [API IBGE - Documentação](https://servicodados.ibge.gov.br/api/docs)
- [Código de municípios IBGE](https://www.ibge.gov.br/explica/codigos-dos-municipios.php)

## Suporte

Para dúvidas sobre:
- **Dados INEP:** atendimento@inep.gov.br
- **API IBGE:** https://www.ibge.gov.br/
- **Sistema Inscribo:** consultar documentação principal
