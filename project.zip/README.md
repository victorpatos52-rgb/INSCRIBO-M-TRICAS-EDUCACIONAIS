# Inscribo Métricas Educacionais

Sistema premium de relatórios estratégicos de matrículas escolares baseado em dados oficiais do INEP, ENEM e IBGE.

## Stack Tecnológica

- **Frontend**: React 18 + TypeScript + Tailwind CSS 4
- **Routing**: React Router 7
- **Backend**: Supabase (PostgreSQL + Edge Functions com Hono)
- **IA**: Google Gemini API
- **Gráficos**: Recharts
- **PDF**: jsPDF + html2canvas
- **Deploy**: Vercel (frontend) + Supabase (backend)

## Configuração do Projeto

### 1. Configurar Supabase

1. Acesse [supabase.com](https://supabase.com) e crie um novo projeto
2. Copie a URL do projeto e as chaves (anon key e service role key)
3. No painel Supabase, vá em SQL Editor
4. Execute o script completo em `/supabase/schema.sql`
5. Aguarde a criação das tabelas e dados de exemplo

### 2. Configurar Variáveis de Ambiente no Supabase

No painel Supabase, vá em **Settings → Edge Functions → Manage secrets**:

```bash
GEMINI_API_KEY=sua_chave_gemini_aqui
```

Para obter a chave Gemini:
- Acesse [https://makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)
- Crie uma nova API key
- Copie e adicione no Supabase

### 3. Atualizar Informações do Supabase no Código

Edite o arquivo `/utils/supabase/info.tsx`:

```typescript
export const projectId = 'SEU_PROJECT_ID';
export const publicAnonKey = 'SUA_ANON_KEY';
```

### 4. Instalar Dependências

```bash
npm install
```

### 5. Executar Localmente

```bash
npm run dev
```

## Estrutura do Banco de Dados

### Tabelas Principais

**escolas**
- Armazena dados cadastrais das instituições de ensino
- Campos: codigo_inep, nome, cidade, estado, dependencia

**matriculas**
- Histórico de matrículas por ano e segmento
- Campos: escola_id, ano, infantil, fundamental1, fundamental2, medio, total

**enem**
- Resultados do ENEM por escola e ano
- Campos: escola_id, ano, media_total, redacao, matematica, linguagens

**relatorios**
- Relatórios gerados com token de acesso
- Campos: escola_id, token, data_geracao, resumo_executivo, projecoes_json

**configuracoes**
- Parâmetros globais do sistema
- Campos: taxa_conversao_padrao, taxa_evasao_padrao

## API Endpoints (Backend)

### POST /make-server-ec6f1a33/search-schools
Busca escolas por nome, código INEP, cidade ou estado

**Request:**
```json
{
  "query": "Colégio Exemplo",
  "cidade": "São Paulo",
  "estado": "SP"
}
```

**Response:**
```json
{
  "escolas": [
    {
      "id": "uuid",
      "codigo_inep": "35001234",
      "nome": "Colégio Exemplo Paulista",
      "cidade": "São Paulo",
      "estado": "SP",
      "dependencia": "Privada"
    }
  ]
}
```

### POST /make-server-ec6f1a33/generate-report
Gera relatório estratégico completo para uma escola

**Request:**
```json
{
  "escola_id": "uuid-da-escola"
}
```

**Response:**
```json
{
  "success": true,
  "token": "token-gerado",
  "relatorio_id": "uuid"
}
```

### GET /make-server-ec6f1a33/report/:token
Recupera relatório por token

**Response:**
```json
{
  "relatorio": { ... },
  "matriculas": [ ... ],
  "projecoes": {
    "metrics": { ... },
    "analiseIA": { ... },
    "ibgeData": { ... },
    "enem": [ ... ]
  }
}
```

## Fluxo de Uso

1. **Buscar Escola**: Usuário busca por nome, código INEP, cidade ou estado
2. **Selecionar Escola**: Clica em "Gerar Relatório" na escola desejada
3. **Processamento**: Backend busca dados históricos, ENEM, IBGE e gera análise com Gemini
4. **Visualização**: Relatório completo com gráficos, projeções e estratégias
5. **Exportação**: Download em PDF com layout executivo

## Cálculos Implementados

### Crescimento Anual
```
(ano_atual - ano_anterior) / ano_anterior * 100
```

### Taxa Média de Crescimento
```
média aritmética dos últimos 3 anos
```

### Market Share
```
(matriculas_escola / total_mercado_privado) * 100
```

### Reposição por Evasão
```
total_alunos * taxa_evasao
```

### Leads Necessários
```
(novas_matriculas + reposicao) / taxa_conversao
```

### Projeções (3 cenários)
- **Conservadora**: metade da taxa média
- **Moderada**: taxa média histórica
- **Agressiva**: taxa média + crescimento demográfico

## Inteligência Artificial (Gemini)

O sistema envia para o Gemini:
- Dados históricos de matrícula
- Métricas calculadas (crescimento, market share, etc.)
- Dados demográficos do IBGE
- Resultados do ENEM

E recebe análise estratégica contendo:
- Resumo executivo
- Diagnóstico detalhado
- Identificação de riscos
- Oportunidades de mercado
- Meta recomendada com justificativa
- Estratégia de crescimento
- Plano de captação (ações específicas)
- Recomendações geográficas
- Recomendações executivas prioritárias

## Deploy

### Frontend (Vercel)

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

### Backend (Supabase Edge Functions)

Já está configurado e rodando no Supabase automaticamente.

## Dados de Exemplo

O sistema vem com dados de exemplo pré-carregados:
- 3 escolas cadastradas
- Histórico de matrículas 2023-2025
- Dados ENEM 2023-2024

Para adicionar mais escolas, insira diretamente no Supabase ou crie uma interface administrativa.

## Integração IBGE

Atualmente usa dados simulados. Para integrar API real do IBGE:

1. Acesse [API IBGE](https://servicodados.ibge.gov.br/api/docs)
2. Implemente chamadas às APIs:
   - População por faixa etária
   - Indicadores socioeconômicos
   - Renda média
3. Atualize a função `fetchIBGEData` em `/supabase/functions/server/index.tsx`

## Segurança

- Tokens únicos para cada relatório
- Row Level Security (RLS) habilitado
- Relatórios não indexáveis
- Opção de expiração e senha (extensível)

## Próximos Passos

- [ ] Integração real com API do IBGE
- [ ] Import em massa de dados do INEP
- [ ] Painel administrativo
- [ ] Sistema de assinaturas
- [ ] Análise comparativa entre escolas
- [ ] Dashboard de mercado regional
- [ ] Alertas automáticos de oportunidades
- [ ] Exportação em Excel

## Suporte

Para dúvidas ou problemas:
1. Verifique os logs no console do navegador
2. Verifique os logs do Supabase Edge Functions
3. Confirme que a GEMINI_API_KEY está configurada
4. Verifique se as tabelas foram criadas corretamente

## Licença

Propriedade de Inscribo © 2026
