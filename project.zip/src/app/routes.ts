import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import Relatorio from "./pages/Relatorio";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/relatorio/:token",
    Component: Relatorio,
  },
]);
