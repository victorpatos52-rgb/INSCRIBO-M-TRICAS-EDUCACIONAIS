import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Search, TrendingUp, BarChart3, FileText } from 'lucide-react';
import { apiRequest } from '../lib/supabase';
import { toast } from 'sonner';
import type { Escola } from '../types';

const ESTADOS = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG',
  'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
];

export default function Home() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [searchResults, setSearchResults] = useState<Escola[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  const handleSearch = async () => {
    if (!query && !cidade && !estado) {
      toast.error('Preencha pelo menos um campo de busca');
      return;
    }

    setLoading(true);
    try {
      const result = await apiRequest('/search-schools', {
        method: 'POST',
        body: JSON.stringify({ query, cidade, estado }),
      });
      setSearchResults(result.escolas || []);
      if (result.escolas.length === 0) {
        toast.info('Nenhuma escola encontrada');
      }
    } catch (error) {
      toast.error('Erro ao buscar escolas: ' + String(error));
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = async (escolaId: string) => {
    setGenerating(true);
    try {
      const result = await apiRequest('/generate-report', {
        method: 'POST',
        body: JSON.stringify({ escola_id: escolaId }),
      });
      
      if (result.success && result.token) {
        toast.success('Relatório gerado com sucesso!');
        navigate(`/relatorio/${result.token}`);
      }
    } catch (error) {
      toast.error('Erro ao gerar relatório: ' + String(error));
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Inscribo Métricas</h1>
              <p className="text-sm text-gray-600">Inteligência Educacional Estratégica</p>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Relatórios Estratégicos de <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Matrícula Escolar</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Análise completa baseada em dados oficiais do INEP, ENEM e IBGE com inteligência artificial
          </p>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <TrendingUp className="w-8 h-8 text-blue-600 mb-2" />
                <CardTitle className="text-lg">Projeções Precisas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Análise de crescimento e tendências baseada em dados históricos</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <BarChart3 className="w-8 h-8 text-purple-600 mb-2" />
                <CardTitle className="text-lg">Dados Oficiais</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">INEP, ENEM e IBGE integrados em tempo real</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <FileText className="w-8 h-8 text-indigo-600 mb-2" />
                <CardTitle className="text-lg">Relatório Premium</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">PDF executivo com estratégias e recomendações</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Search Form */}
        <Card className="max-w-3xl mx-auto shadow-xl border-0">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Search className="w-6 h-6" />
              Buscar Escola
            </CardTitle>
            <CardDescription className="text-blue-50">
              Digite o nome, código INEP, cidade ou estado da escola
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="query">Nome da Escola ou Código INEP</Label>
                <Input
                  id="query"
                  placeholder="Ex: Colégio ABC ou 12345678"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input
                    id="cidade"
                    placeholder="Ex: São Paulo"
                    value={cidade}
                    onChange={(e) => setCidade(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  />
                </div>

                <div>
                  <Label htmlFor="estado">Estado</Label>
                  <Select value={estado} onValueChange={setEstado}>
                    <SelectTrigger id="estado">
                      <SelectValue placeholder="Selecione o estado" />
                    </SelectTrigger>
                    <SelectContent>
                      {ESTADOS.map((uf) => (
                        <SelectItem key={uf} value={uf}>
                          {uf}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                onClick={handleSearch} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                size="lg"
              >
                {loading ? 'Buscando...' : 'Buscar Escolas'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <div className="max-w-3xl mx-auto mt-8">
            <h3 className="text-xl font-semibold mb-4">Resultados da Busca</h3>
            <div className="space-y-3">
              {searchResults.map((escola) => (
                <Card key={escola.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-lg text-gray-900">{escola.nome}</h4>
                        <p className="text-sm text-gray-600 mt-1">
                          {escola.cidade}/{escola.estado} • INEP: {escola.codigo_inep}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {escola.dependencia}
                        </p>
                      </div>
                      <Button
                        onClick={() => handleGenerateReport(escola.id)}
                        disabled={generating}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        {generating ? 'Gerando...' : 'Gerar Relatório'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-gray-600">
          <p>© 2026 Inscribo Métricas Educacionais • Dados oficiais INEP, ENEM e IBGE</p>
        </div>
      </footer>
    </div>
  );
}
