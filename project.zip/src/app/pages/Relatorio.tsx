import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Separator } from '../components/ui/separator';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, Download, Share2, TrendingUp, TrendingDown, 
  Users, Target, AlertCircle, CheckCircle, BarChart3,
  Building2, MapPin, Calendar, FileText
} from 'lucide-react';
import { apiRequest } from '../lib/supabase';
import { toast } from 'sonner';
import type { Relatorio, Escola, Matricula, ProjecoesData } from '../types';
import GrowthChart from '../components/GrowthChart';
import SegmentChart from '../components/SegmentChart';
import ProjectionChart from '../components/ProjectionChart';
import MetaSimulator from '../components/MetaSimulator';
import { generatePDF } from '../lib/pdf-generator';

export default function Relatorio() {
  const { token } = useParams();
  const navigate = useNavigate();
  const reportRef = useRef<HTMLDivElement>(null);
  
  const [loading, setLoading] = useState(true);
  const [relatorio, setRelatorio] = useState<Relatorio | null>(null);
  const [escola, setEscola] = useState<Escola | null>(null);
  const [matriculas, setMatriculas] = useState<Matricula[]>([]);
  const [projecoes, setProjecoes] = useState<ProjecoesData | null>(null);

  useEffect(() => {
    loadReport();
  }, [token]);

  const loadReport = async () => {
    if (!token) return;
    
    setLoading(true);
    try {
      const result = await apiRequest(`/report/${token}`);
      setRelatorio(result.relatorio);
      setEscola(result.relatorio.escolas);
      setMatriculas(result.matriculas);
      setProjecoes(result.projecoes);
    } catch (error) {
      toast.error('Erro ao carregar relatório: ' + String(error));
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!reportRef.current || !escola || !relatorio) return;
    
    toast.info('Gerando PDF...');
    try {
      await generatePDF(reportRef.current, escola.nome);
      toast.success('PDF gerado com sucesso!');
    } catch (error) {
      toast.error('Erro ao gerar PDF: ' + String(error));
      console.error(error);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    toast.success('Link copiado para a área de transferência!');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando relatório...</p>
        </div>
      </div>
    );
  }

  if (!relatorio || !escola || !projecoes) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Relatório não encontrado</h2>
            <p className="text-gray-600 mb-4">O relatório que você está procurando não existe ou foi removido.</p>
            <Button onClick={() => navigate('/')}>Voltar para busca</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { metrics, analiseIA, ibgeData, enem } = projecoes;
  const ultimaMatricula = matriculas[matriculas.length - 1];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={() => navigate('/')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Relatório Estratégico</h1>
                <p className="text-sm text-gray-600">{escola.nome}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
              <Button onClick={handleDownloadPDF} className="bg-gradient-to-r from-blue-600 to-purple-600">
                <Download className="w-4 h-4 mr-2" />
                Baixar PDF
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div ref={reportRef} className="container mx-auto px-4 py-8 max-w-7xl">
        {/* School Info */}
        <Card className="mb-8 border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Building2 className="w-5 h-5 text-blue-600" />
                  <h2 className="text-2xl font-bold text-gray-900">{escola.nome}</h2>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {escola.cidade}/{escola.estado}
                  </span>
                  <span>INEP: {escola.codigo_inep}</span>
                  <Badge variant="secondary">{escola.dependencia}</Badge>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-sm text-gray-600 mb-1">
                  <Calendar className="w-4 h-4" />
                  {new Date(relatorio.data_geracao).toLocaleDateString('pt-BR')}
                </div>
                {ultimaMatricula && (
                  <div className="text-3xl font-bold text-blue-600">
                    {ultimaMatricula.total.toLocaleString()}
                  </div>
                )}
                <div className="text-xs text-gray-600">Total de Alunos</div>
              </div>
            </div>

            {/* Key Metrics */}
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  {metrics.taxa_media >= 0 ? (
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-600" />
                  )}
                  <span className="text-sm font-medium text-gray-700">Crescimento Médio</span>
                </div>
                <div className={`text-2xl font-bold ${metrics.taxa_media >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metrics.taxa_media.toFixed(1)}%
                </div>
              </div>

              <div className="bg-purple-50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  <span className="text-sm font-medium text-gray-700">Market Share</span>
                </div>
                <div className="text-2xl font-bold text-purple-600">
                  {metrics.market_share.toFixed(1)}%
                </div>
              </div>

              <div className="bg-indigo-50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  <span className="text-sm font-medium text-gray-700">Segmento Dominante</span>
                </div>
                <div className="text-lg font-bold text-indigo-600">
                  {metrics.segmento_dominante}
                </div>
              </div>

              <div className="bg-green-50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium text-gray-700">Potencial Máximo</span>
                </div>
                <div className="text-2xl font-bold text-green-600">
                  {Math.round(metrics.potencial_maximo).toLocaleString()}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Executive Summary */}
        <Card className="mb-8 border-0 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Resumo Executivo
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <p className="text-gray-700 leading-relaxed whitespace-pre-line">
              {analiseIA.resumo}
            </p>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="evolucao" className="mb-8">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="evolucao">Evolução</TabsTrigger>
            <TabsTrigger value="distribuicao">Distribuição</TabsTrigger>
            <TabsTrigger value="projecoes">Projeções</TabsTrigger>
            <TabsTrigger value="simulador">Simulador</TabsTrigger>
            <TabsTrigger value="estrategia">Estratégia</TabsTrigger>
          </TabsList>

          <TabsContent value="evolucao">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Evolução Histórica de Matrículas</CardTitle>
              </CardHeader>
              <CardContent>
                <GrowthChart matriculas={matriculas} />
                
                <Separator className="my-6" />
                
                <div className="space-y-3">
                  <h4 className="font-semibold">Crescimento Ano a Ano</h4>
                  {metrics.crescimento_anual.map((item) => (
                    <div key={item.ano} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">{item.ano}</span>
                      <div className="flex items-center gap-2">
                        {item.crescimento >= 0 ? (
                          <TrendingUp className="w-4 h-4 text-green-600" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-red-600" />
                        )}
                        <span className={`font-bold ${item.crescimento >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {item.crescimento > 0 ? '+' : ''}{item.crescimento.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="distribuicao">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Distribuição por Segmento</CardTitle>
              </CardHeader>
              <CardContent>
                <SegmentChart matricula={ultimaMatricula} />
                
                <Separator className="my-6" />
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3">Dados Demográficos (IBGE)</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between p-2 bg-blue-50 rounded">
                        <span className="text-sm">População 0-4 anos</span>
                        <span className="font-bold">{ibgeData.populacao_0_4.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-blue-50 rounded">
                        <span className="text-sm">População 5-9 anos</span>
                        <span className="font-bold">{ibgeData.populacao_5_9.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-blue-50 rounded">
                        <span className="text-sm">População 10-14 anos</span>
                        <span className="font-bold">{ibgeData.populacao_10_14.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-blue-50 rounded">
                        <span className="text-sm">População 15-17 anos</span>
                        <span className="font-bold">{ibgeData.populacao_15_17.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {enem.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Desempenho ENEM</h4>
                      <div className="space-y-2">
                        {enem.map((e) => (
                          <div key={e.ano} className="p-3 bg-purple-50 rounded-lg">
                            <div className="flex justify-between items-center mb-2">
                              <span className="font-bold">{e.ano}</span>
                              <Badge variant="secondary">Média: {e.media_total.toFixed(1)}</Badge>
                            </div>
                            <div className="grid grid-cols-3 gap-2 text-xs">
                              <div>
                                <div className="text-gray-600">Matemática</div>
                                <div className="font-bold">{e.matematica.toFixed(1)}</div>
                              </div>
                              <div>
                                <div className="text-gray-600">Linguagens</div>
                                <div className="font-bold">{e.linguagens.toFixed(1)}</div>
                              </div>
                              <div>
                                <div className="text-gray-600">Redação</div>
                                <div className="font-bold">{e.redacao.toFixed(1)}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projecoes">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Projeções de Crescimento (3 anos)</CardTitle>
              </CardHeader>
              <CardContent>
                <ProjectionChart 
                  baseValue={ultimaMatricula.total} 
                  taxaMedia={metrics.taxa_media}
                  crescimentoDemografico={ibgeData.crescimento_anual * 100}
                />
                
                <Separator className="my-6" />
                
                <div className="bg-blue-50 rounded-lg p-6">
                  <h4 className="font-semibold mb-4">Meta Recomendada</h4>
                  <p className="text-gray-700 leading-relaxed">
                    {analiseIA.meta_recomendada}
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="simulador">
            <MetaSimulator 
              totalAtual={ultimaMatricula.total}
              taxaEvasao={0.05}
              taxaConversao={0.15}
            />
          </TabsContent>

          <TabsContent value="estrategia">
            <div className="space-y-6">
              {/* Diagnóstico */}
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-blue-600 text-white">
                  <CardTitle>Diagnóstico Estratégico</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {analiseIA.diagnostico}
                  </p>
                </CardContent>
              </Card>

              {/* Riscos e Oportunidades */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-0 shadow-lg">
                  <CardHeader className="bg-red-50">
                    <CardTitle className="flex items-center gap-2 text-red-700">
                      <AlertCircle className="w-5 h-5" />
                      Riscos Identificados
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-2">
                      {analiseIA.riscos.map((risco, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2"></span>
                          <span className="text-sm text-gray-700">{risco}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg">
                  <CardHeader className="bg-green-50">
                    <CardTitle className="flex items-center gap-2 text-green-700">
                      <CheckCircle className="w-5 h-5" />
                      Oportunidades
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-2">
                      {analiseIA.oportunidades.map((oportunidade, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2"></span>
                          <span className="text-sm text-gray-700">{oportunidade}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Estratégia de Crescimento */}
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-purple-600 text-white">
                  <CardTitle>Estratégia de Crescimento</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line mb-6">
                    {analiseIA.estrategia_crescimento}
                  </p>
                  
                  <Separator className="my-6" />
                  
                  <h4 className="font-semibold mb-4">Plano Geográfico</h4>
                  <p className="text-gray-700 leading-relaxed">
                    {analiseIA.plano_geografico}
                  </p>
                </CardContent>
              </Card>

              {/* Plano de Captação */}
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-indigo-600 text-white">
                  <CardTitle>Plano de Captação</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    {analiseIA.plano_captacao.map((acao, idx) => (
                      <div key={idx} className="flex items-start gap-3 p-3 bg-indigo-50 rounded-lg">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold flex-shrink-0">
                          {idx + 1}
                        </div>
                        <p className="text-gray-700 pt-1">{acao}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recomendações Executivas */}
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <CardTitle>Recomendações Executivas Prioritárias</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    {analiseIA.recomendacoes_executivas.map((rec, idx) => (
                      <div key={idx} className="flex items-start gap-3 p-4 border-l-4 border-blue-600 bg-blue-50">
                        <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                        <p className="text-gray-700">{rec}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-gray-600">
          <p>Relatório gerado por Inscribo Métricas Educacionais</p>
          <p className="text-xs mt-1">Baseado em dados oficiais do INEP, ENEM e IBGE</p>
        </div>
      </footer>
    </div>
  );
}
