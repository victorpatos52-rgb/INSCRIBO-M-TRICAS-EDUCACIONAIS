import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import type { Matricula } from '../types';

interface SegmentChartProps {
  matricula: Matricula;
}

const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b'];

export default function SegmentChart({ matricula }: SegmentChartProps) {
  const data = [
    { name: 'Educação Infantil', value: matricula.infantil },
    { name: 'Fundamental I', value: matricula.fundamental1 },
    { name: 'Fundamental II', value: matricula.fundamental2 },
    { name: 'Ensino Médio', value: matricula.medio },
  ];

  return (
    <ResponsiveContainer width="100%" height={400}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
          outerRadius={120}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}
