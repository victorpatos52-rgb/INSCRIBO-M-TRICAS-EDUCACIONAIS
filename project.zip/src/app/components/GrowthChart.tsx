import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { Matricula } from '../types';

interface GrowthChartProps {
  matriculas: Matricula[];
}

export default function GrowthChart({ matriculas }: GrowthChartProps) {
  const data = matriculas.map((m) => ({
    ano: m.ano,
    'Educação Infantil': m.infantil,
    'Fundamental I': m.fundamental1,
    'Fundamental II': m.fundamental2,
    'Ensino Médio': m.medio,
    'Total': m.total,
  }));

  return (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="ano" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="Educação Infantil" stroke="#3b82f6" strokeWidth={2} />
        <Line type="monotone" dataKey="Fundamental I" stroke="#8b5cf6" strokeWidth={2} />
        <Line type="monotone" dataKey="Fundamental II" stroke="#ec4899" strokeWidth={2} />
        <Line type="monotone" dataKey="Ensino Médio" stroke="#f59e0b" strokeWidth={2} />
        <Line type="monotone" dataKey="Total" stroke="#10b981" strokeWidth={3} />
      </LineChart>
    </ResponsiveContainer>
  );
}
