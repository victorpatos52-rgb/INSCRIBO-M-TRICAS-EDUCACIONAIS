import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ProjectionChartProps {
  baseValue: number;
  taxaMedia: number;
  crescimentoDemografico: number;
}

export default function ProjectionChart({ baseValue, taxaMedia, crescimentoDemografico }: ProjectionChartProps) {
  const currentYear = 2025;
  
  // Conservadora: metade da taxa média
  const taxaConservadora = taxaMedia / 2;
  
  // Moderada: taxa média
  const taxaModerada = taxaMedia;
  
  // Agressiva: taxa média + crescimento demográfico
  const taxaAgressiva = taxaMedia + crescimentoDemografico;

  const data = [
    {
      ano: currentYear,
      'Conservadora': baseValue,
      'Moderada': baseValue,
      'Agressiva': baseValue,
    },
    {
      ano: currentYear + 1,
      'Conservadora': Math.round(baseValue * (1 + taxaConservadora / 100)),
      'Moderada': Math.round(baseValue * (1 + taxaModerada / 100)),
      'Agressiva': Math.round(baseValue * (1 + taxaAgressiva / 100)),
    },
    {
      ano: currentYear + 2,
      'Conservadora': Math.round(baseValue * Math.pow(1 + taxaConservadora / 100, 2)),
      'Moderada': Math.round(baseValue * Math.pow(1 + taxaModerada / 100, 2)),
      'Agressiva': Math.round(baseValue * Math.pow(1 + taxaAgressiva / 100, 2)),
    },
    {
      ano: currentYear + 3,
      'Conservadora': Math.round(baseValue * Math.pow(1 + taxaConservadora / 100, 3)),
      'Moderada': Math.round(baseValue * Math.pow(1 + taxaModerada / 100, 3)),
      'Agressiva': Math.round(baseValue * Math.pow(1 + taxaAgressiva / 100, 3)),
    },
  ];

  return (
    <div>
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="ano" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="Conservadora" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" />
          <Line type="monotone" dataKey="Moderada" stroke="#3b82f6" strokeWidth={3} />
          <Line type="monotone" dataKey="Agressiva" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" />
        </LineChart>
      </ResponsiveContainer>

      <div className="grid md:grid-cols-3 gap-4 mt-6">
        <div className="bg-orange-50 rounded-lg p-4">
          <h4 className="font-semibold text-orange-700 mb-2">Cenário Conservador</h4>
          <p className="text-sm text-gray-600 mb-2">Taxa: {taxaConservadora.toFixed(2)}% ao ano</p>
          <div className="text-2xl font-bold text-orange-600">
            {data[3]['Conservadora'].toLocaleString()}
          </div>
          <p className="text-xs text-gray-600">alunos em {currentYear + 3}</p>
        </div>

        <div className="bg-blue-50 rounded-lg p-4">
          <h4 className="font-semibold text-blue-700 mb-2">Cenário Moderado</h4>
          <p className="text-sm text-gray-600 mb-2">Taxa: {taxaModerada.toFixed(2)}% ao ano</p>
          <div className="text-2xl font-bold text-blue-600">
            {data[3]['Moderada'].toLocaleString()}
          </div>
          <p className="text-xs text-gray-600">alunos em {currentYear + 3}</p>
        </div>

        <div className="bg-green-50 rounded-lg p-4">
          <h4 className="font-semibold text-green-700 mb-2">Cenário Agressivo</h4>
          <p className="text-sm text-gray-600 mb-2">Taxa: {taxaAgressiva.toFixed(2)}% ao ano</p>
          <div className="text-2xl font-bold text-green-600">
            {data[3]['Agressiva'].toLocaleString()}
          </div>
          <p className="text-xs text-gray-600">alunos em {currentYear + 3}</p>
        </div>
      </div>
    </div>
  );
}
