import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Target, TrendingUp, Users } from 'lucide-react';

interface MetaSimulatorProps {
  totalAtual: number;
  taxaEvasao: number;
  taxaConversao: number;
}

export default function MetaSimulator({ totalAtual, taxaEvasao, taxaConversao }: MetaSimulatorProps) {
  const [meta, setMeta] = useState(10);
  const [conversao, setConversao] = useState(taxaConversao * 100);
  const [evasao, setEvasao] = useState(taxaEvasao * 100);

  const novasMatriculas = Math.round(totalAtual * (meta / 100));
  const reposicao = Math.round(totalAtual * (evasao / 100));
  const totalNecessario = novasMatriculas + reposicao;
  const leadsNecessarios = Math.round(totalNecessario / (conversao / 100));

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5" />
          Simulador de Metas
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Controls */}
          <div className="space-y-6">
            <div>
              <Label className="mb-3 block">Meta de Crescimento: {meta}%</Label>
              <Slider
                value={[meta]}
                onValueChange={(value) => setMeta(value[0])}
                min={0}
                max={50}
                step={1}
                className="mb-2"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>0%</span>
                <span>50%</span>
              </div>
            </div>

            <div>
              <Label htmlFor="conversao" className="mb-2 block">Taxa de Conversão (%)</Label>
              <Input
                id="conversao"
                type="number"
                value={conversao}
                onChange={(e) => setConversao(Number(e.target.value))}
                min={1}
                max={100}
              />
            </div>

            <div>
              <Label htmlFor="evasao" className="mb-2 block">Taxa de Evasão (%)</Label>
              <Input
                id="evasao"
                type="number"
                value={evasao}
                onChange={(e) => setEvasao(Number(e.target.value))}
                min={0}
                max={50}
              />
            </div>

            <Button 
              onClick={() => {
                setMeta(10);
                setConversao(taxaConversao * 100);
                setEvasao(taxaEvasao * 100);
              }}
              variant="outline"
              className="w-full"
            >
              Resetar Valores
            </Button>
          </div>

          {/* Results */}
          <div className="space-y-4">
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">Novas Matrículas Necessárias</span>
              </div>
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {novasMatriculas.toLocaleString()}
              </div>
              <p className="text-xs text-gray-600">
                Para crescer {meta}% sobre base atual de {totalAtual.toLocaleString()} alunos
              </p>
            </div>

            <div className="bg-orange-50 rounded-lg p-6">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-5 h-5 text-orange-600" />
                <span className="text-sm font-medium text-gray-700">Reposição por Evasão</span>
              </div>
              <div className="text-3xl font-bold text-orange-600 mb-1">
                {reposicao.toLocaleString()}
              </div>
              <p className="text-xs text-gray-600">
                Estimativa com taxa de evasão de {evasao}%
              </p>
            </div>

            <div className="bg-purple-50 rounded-lg p-6">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-5 h-5 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">Total de Matrículas</span>
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-1">
                {totalNecessario.toLocaleString()}
              </div>
              <p className="text-xs text-gray-600">
                Novas matrículas + reposição
              </p>
            </div>

            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg p-6 text-white">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-5 h-5" />
                <span className="text-sm font-medium">Leads Necessários</span>
              </div>
              <div className="text-4xl font-bold mb-1">
                {leadsNecessarios.toLocaleString()}
              </div>
              <p className="text-xs opacity-90">
                Com taxa de conversão de {conversao}%
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 p-6 bg-gray-50 rounded-lg">
          <h4 className="font-semibold mb-3">Resumo do Cenário</h4>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Base atual:</span>
              <span className="font-bold ml-2">{totalAtual.toLocaleString()} alunos</span>
            </div>
            <div>
              <span className="text-gray-600">Meta de crescimento:</span>
              <span className="font-bold ml-2">{meta}%</span>
            </div>
            <div>
              <span className="text-gray-600">Total projetado:</span>
              <span className="font-bold ml-2">{(totalAtual + novasMatriculas).toLocaleString()} alunos</span>
            </div>
            <div>
              <span className="text-gray-600">Crescimento absoluto:</span>
              <span className="font-bold ml-2">+{novasMatriculas.toLocaleString()} alunos</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
