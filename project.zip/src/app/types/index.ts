export interface Escola {
  id: string;
  codigo_inep: string;
  nome: string;
  cidade: string;
  estado: string;
  dependencia: string;
}

export interface Matricula {
  id: string;
  escola_id: string;
  ano: number;
  infantil: number;
  fundamental1: number;
  fundamental2: number;
  medio: number;
  total: number;
}

export interface Enem {
  id: string;
  escola_id: string;
  ano: number;
  media_total: number;
  redacao: number;
  matematica: number;
  linguagens: number;
}

export interface Relatorio {
  id: string;
  escola_id: string;
  token: string;
  data_geracao: string;
  resumo_executivo: string;
  projecoes_json: string;
}

export interface IBGEData {
  populacao_0_4: number;
  populacao_5_9: number;
  populacao_10_14: number;
  populacao_15_17: number;
  crescimento_anual: number;
  renda_media: number;
}

export interface Metrics {
  crescimento_anual: Array<{ ano: number; crescimento: number }>;
  taxa_media: number;
  segmento_dominante: string;
  segmento_em_queda: string;
  market_share: number;
  potencial_maximo: number;
  taxa_reposicao: number;
}

export interface AnaliseIA {
  resumo: string;
  diagnostico: string;
  riscos: string[];
  oportunidades: string[];
  meta_recomendada: string;
  estrategia_crescimento: string;
  plano_captacao: string[];
  plano_geografico: string;
  recomendacoes_executivas: string[];
}

export interface ProjecoesData {
  metrics: Metrics;
  analiseIA: AnaliseIA;
  ibgeData: IBGEData;
  enem: Enem[];
}
